#include "behavior.h"

using namespace gazebo;

Behavior::Behavior(double kGain)
{
    this->_kGain = kGain;
}
